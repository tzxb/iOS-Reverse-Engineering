'use strict';

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(function () {
    var Queue = function () {
        function Queue() {
            _classCallCheck(this, Queue);

            this.queue = [];
        }

        _createClass(Queue, [{
            key: 'push',
            value: function push(message) {
                this.queue.push(message);
            }
        }, {
            key: 'getQueue',
            value: function getQueue() {
                return this.queue;
            }
        }, {
            key: 'pop',
            value: function pop() {
                var delta = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

                var resQueue = [];
                while (delta--) {
                    resQueue.push(this.queue.pop());
                }
                return resQueue;
            }
        }, {
            key: 'del',
            value: function del(funcQuote) {
                this.queue = this.queue.filter(function (item) {
                    return item.handler !== funcQuote;
                });
            }
        }, {
            key: 'clear',
            value: function clear() {
                this.queue = [];
            }
        }]);

        return Queue;
    }();

    var QueueSet = function () {
        function QueueSet() {
            _classCallCheck(this, QueueSet);

            this.queueSet = {};
        }

        _createClass(QueueSet, [{
            key: 'get',
            value: function get(namespace) {
                if (!this.queueSet[namespace]) {
                    this.queueSet[namespace] = new Queue();
                }
                return this.queueSet[namespace];
            }
        }, {
            key: 'pushTo',
            value: function pushTo(namespace, message) {
                this.get(namespace).push(message);
            }
        }, {
            key: 'has',
            value: function has(namespace) {
                return !!this.queueSet[namespace];
            }
        }, {
            key: 'del',
            value: function del(namespace, funcQuote) {
                var _this = this;

                if (!funcQuote) {
                    this.queueSet[namespace].clear();
                } else if (namespace === '*') {
                    Object.keys(this.queueSet).forEach(function (queueName) {
                        var queue = _this.queueSet[queueName];
                        queue && queue.del(funcQuote);
                    });
                } else {
                    this.queueSet[namespace].del(funcQuote);
                }
            }
        }]);

        return QueueSet;
    }();

    var EventsEmitter = function () {
        function EventsEmitter() {
            _classCallCheck(this, EventsEmitter);

            this.handlerQueueSet = new QueueSet();
            this.messageQueueSet = new QueueSet();
        }

        _createClass(EventsEmitter, [{
            key: 'fireMessage',
            value: function fireMessage(message) {
                var _this2 = this;

                if (message && message.type && this.handlerQueueSet.get(message.type)) {
                    this.messageQueueSet.pushTo(message.type, message);
                    this.handlerQueueSet.get(message.type).getQueue().forEach(function (item) {
                        _this2.handlerWrapper(item, message.type, message);
                    });
                    this.handlerQueueSet.get('*').getQueue().forEach(function (item) {
                        _this2.handlerWrapper(item, '*', message);
                    });
                }
                return this;
            }
        }, {
            key: 'onMessage',
            value: function onMessage(type, handler) {
                var _this3 = this;

                var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};


                if (Object.prototype.toString.call(type) === '[object Array]') {
                    type.forEach(function (oneType) {
                        return _this3.onMessage(oneType, handler, options);
                    });
                    return this;
                }

                this.handlerQueueSet.pushTo(type, {
                    handler: handler,
                    once: options.once
                });
                if (options.listenPreviousEvent === true && this.messageQueueSet.has(type)) {
                    this.handlerWrapper({ handler: handler, once: options.once }, type, this.messageQueueSet.get(type).getQueue());
                }
                return this;
            }
        }, {
            key: 'delHandler',
            value: function delHandler(type, handler) {
                this.handlerQueueSet.del(type, handler);
                return this;
            }
        }, {
            key: 'handlerWrapper',
            value: function handlerWrapper(_ref, type, message) {
                var handler = _ref.handler,
                    once = _ref.once;

                if (!handler) {
                    return false;
                }
                handler.call(window, message);

                if (once) {
                    this.handlerQueueSet.del(type, handler);
                }
                return true;
            }
        }], [{
            key: 'merge',
            value: function merge() {
                var mergedEventsEmitter = new EventsEmitter();

                for (var _len = arguments.length, communicators = Array(_len), _key = 0; _key < _len; _key++) {
                    communicators[_key] = arguments[_key];
                }

                [].concat(communicators).forEach(function (communicator) {
                    communicator.onMessage('*', function (e) {
                        return mergedEventsEmitter.fireMessage(e);
                    });
                });
                return mergedEventsEmitter;
            }
        }]);

        return EventsEmitter;
    }();

    var $ = {
        isIOS: /(iPhone|iPod|iPad)/.test(navigator.userAgent) || /P2/.test(navigator.userAgent)
    };

    var hasNoGlobal = typeof swanGlobal === 'undefined';

    var global = typeof swanGlobal === 'undefined' ? window : swanGlobal;

    var globalNative = typeof swanGlobal === 'undefined' ? window : _naSwan;

    var ioswebviewList = [{
        'name': 'baidu.getPushSettingStateSync',
        'authority': 'swanAPI',
        'path': '/getPushSettingStateSync',
        'args': [],
        'invoke': 'swan.prompt'
    }, {
        'name': 'baidu.getPrivateGetUserInfo',
        'authority': 'swanAPI',
        'path': '/privateGetUserInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.openWalkNavigation',
        'authority': 'swanAPI',
        'path': '/map/openWalkNavigation',
        'args': [{
            'name': 'latitude',
            'value': 'string'
        }, {
            'name': 'longitude',
            'value': 'string'
        }, {
            'name': 'guideKey',
            'value': 'string='
        }, {
            'name': 'guideIcon',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.requestWalletPolymerPayment',
        'authority': 'swanAPI',
        'path': '/requestWalletPolymerPayment',
        'args': [{
            'name': 'orderInfo',
            'value': 'object'
        }, {
            'name': 'reqData',
            'value': 'object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.thirdPartyLogin',
        'authority': 'swanAPI',
        'path': '/thirdPartyLogin',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }, {
            'name': 'timeout',
            'value': 'string='
        }, {
            'name': 'type',
            'value': {
                'oneOf': ['weibo', 'qq', 'weixin', 'sms']
            }
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getStoken',
        'authority': 'swanAPI',
        'path': '/getStoken',
        'args': [{
            'name': 'tpl',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.guidePushSetting',
        'authority': 'swanAPI',
        'path': '/guidePushSetting',
        'args': [{
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getCommonSysInfo',
        'authority': 'swanAPI',
        'path': '/getCommonSysInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.tts.speak',
        'authority': 'tts',
        'path': '/speak',
        'args': [{
            'name': 'text',
            'value': 'string'
        }, {
            'name': 'auto',
            'value': 'boolean='
        }, {
            'name': 'speed',
            'value': 'string='
        }, {
            'name': 'pitch',
            'value': 'string='
        }, {
            'name': 'speaker',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.tts.stop',
        'authority': 'tts',
        'path': '/stop',
        'args': [],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.tts.resume',
        'authority': 'tts',
        'path': '/resume',
        'args': [],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.tts.suspend',
        'authority': 'tts',
        'path': '/suspend',
        'args': [],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.register',
        'authority': 'swanAPI',
        'path': '/dataChannel/registerReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.pullMessage',
        'authority': 'swanAPI',
        'path': '/im/pullMsg',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.follow',
        'authority': 'follow',
        'path': '/action',
        'args': [{
            'name': 'actionType',
            'value': 'string'
        }, {
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getFollowStatus',
        'authority': 'follow',
        'path': '/getFollowStatus',
        'args': [{
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.sendBroadcast',
        'authority': 'swanAPI',
        'path': '/dataChannel/sendBroadcast',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.unRegister',
        'authority': 'swanAPI',
        'path': '/dataChannel/unregisterReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getBDUSS',
        'authority': 'swanAPI',
        'path': '/getBDUSS',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.openBdboxWebview',
        'authority': 'swanAPI',
        'path': '/pageTransition',
        'args': [{
            'name': 'module',
            'value': 'string='
        }, {
            'name': 'action',
            'value': 'string='
        }, {
            'name': 'scheme',
            'value': 'object='
        }, {
            'name': 'path',
            'value': 'string='
        }, {
            'name': 'authority',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getRealNameInfo',
        'authority': 'swanAPI',
        'path': '/getRealNameInfo',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }, {
        'name': 'baidu.getSeid',
        'authority': 'swanAPI',
        'path': '/quickPay/getSeid',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.message.url',
        'handler': 'bridge'
    }];

    var iosjscList = [{
        'name': 'baidu.getPushSettingStateSync',
        'authority': 'swanAPI',
        'path': '/getPushSettingStateSync',
        'args': [],
        'invoke': 'swan.method.urlArray',
        'method': '_naSwan.bridge.extension.getPushSettingStateSync'
    }, {
        'name': 'baidu.getPrivateGetUserInfo',
        'authority': 'swanAPI',
        'path': '/privateGetUserInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.openWalkNavigation',
        'authority': 'swanAPI',
        'path': '/map/openWalkNavigation',
        'args': [{
            'name': 'latitude',
            'value': 'string'
        }, {
            'name': 'longitude',
            'value': 'string'
        }, {
            'name': 'guideKey',
            'value': 'string='
        }, {
            'name': 'guideIcon',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.requestWalletPolymerPayment',
        'authority': 'swanAPI',
        'path': '/requestWalletPolymerPayment',
        'args': [{
            'name': 'orderInfo',
            'value': 'object'
        }, {
            'name': 'reqData',
            'value': 'object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.thirdPartyLogin',
        'authority': 'swanAPI',
        'path': '/thirdPartyLogin',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }, {
            'name': 'timeout',
            'value': 'string='
        }, {
            'name': 'type',
            'value': {
                'oneOf': ['weibo', 'qq', 'weixin', 'sms']
            }
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getStoken',
        'authority': 'swanAPI',
        'path': '/getStoken',
        'args': [{
            'name': 'tpl',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.guidePushSetting',
        'authority': 'swanAPI',
        'path': '/guidePushSetting',
        'args': [{
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getCommonSysInfo',
        'authority': 'swanAPI',
        'path': '/getCommonSysInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.tts.speak',
        'authority': 'tts',
        'path': '/speak',
        'args': [{
            'name': 'text',
            'value': 'string'
        }, {
            'name': 'auto',
            'value': 'boolean='
        }, {
            'name': 'speed',
            'value': 'string='
        }, {
            'name': 'pitch',
            'value': 'string='
        }, {
            'name': 'speaker',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.tts.stop',
        'authority': 'tts',
        'path': '/stop',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.tts.resume',
        'authority': 'tts',
        'path': '/resume',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.tts.suspend',
        'authority': 'tts',
        'path': '/suspend',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.register',
        'authority': 'swanAPI',
        'path': '/dataChannel/registerReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.pullMessage',
        'authority': 'swanAPI',
        'path': '/im/pullMsg',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.follow',
        'authority': 'follow',
        'path': '/action',
        'args': [{
            'name': 'actionType',
            'value': 'string'
        }, {
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getFollowStatus',
        'authority': 'follow',
        'path': '/getFollowStatus',
        'args': [{
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.sendBroadcast',
        'authority': 'swanAPI',
        'path': '/dataChannel/sendBroadcast',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.unRegister',
        'authority': 'swanAPI',
        'path': '/dataChannel/unregisterReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getBDUSS',
        'authority': 'swanAPI',
        'path': '/getBDUSS',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.openBdboxWebview',
        'authority': 'swanAPI',
        'path': '/pageTransition',
        'args': [{
            'name': 'module',
            'value': 'string='
        }, {
            'name': 'action',
            'value': 'string='
        }, {
            'name': 'scheme',
            'value': 'object='
        }, {
            'name': 'path',
            'value': 'string='
        }, {
            'name': 'authority',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getRealNameInfo',
        'authority': 'swanAPI',
        'path': '/getRealNameInfo',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }, {
        'name': 'baidu.getSeid',
        'authority': 'swanAPI',
        'path': '/quickPay/getSeid',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.bridge.postMessage'
    }];

    var androidwebviewList = [{
        'name': 'baidu.getPushSettingStateSync',
        'authority': 'swanAPI',
        'path': '/getPushSettingStateSync',
        'args': [],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_aiapps_jsbridge.dispatch'
    }, {
        'name': 'baidu.getPrivateGetUserInfo',
        'authority': 'swanAPI',
        'path': '/privateGetUserInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.launchCloudGame',
        'authority': 'swanAPI',
        'path': '/launchCloudGame',
        'args': [{
            'name': 'scheme',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getPayStatus',
        'authority': 'swanAPI',
        'path': '/quickPay/getPayStatus',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.addCard',
        'authority': 'swanAPI',
        'path': '/quickPay/addCard',
        'args': [{
            'name': 'cardType',
            'value': 'string='
        }, {
            'name': 'issuerId',
            'value': 'string='
        }, {
            'name': 'cardNum',
            'value': 'string'
        }, {
            'name': 'phoneNum',
            'value': 'string'
        }, {
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getCardList',
        'authority': 'swanAPI',
        'path': '/quickPay/getCardList',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'ext',
            'value': 'Object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.launchPay',
        'authority': 'swanAPI',
        'path': '/quickPay/launchPay',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.openWalkNavigation',
        'authority': 'swanAPI',
        'path': '/map/openWalkNavigation',
        'args': [{
            'name': 'latitude',
            'value': 'string'
        }, {
            'name': 'longitude',
            'value': 'string'
        }, {
            'name': 'guideKey',
            'value': 'string='
        }, {
            'name': 'guideIcon',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.requestWalletPolymerPayment',
        'authority': 'swanAPI',
        'path': '/requestWalletPolymerPayment',
        'args': [{
            'name': 'orderInfo',
            'value': 'object'
        }, {
            'name': 'reqData',
            'value': 'object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.thirdPartyLogin',
        'authority': 'swanAPI',
        'path': '/thirdPartyLogin',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }, {
            'name': 'timeout',
            'value': 'string='
        }, {
            'name': 'type',
            'value': {
                'oneOf': ['weibo', 'qq', 'weixin', 'sms']
            }
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getStoken',
        'authority': 'swanAPI',
        'path': '/getStoken',
        'args': [{
            'name': 'tpl',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.guidePushSetting',
        'authority': 'swanAPI',
        'path': '/guidePushSetting',
        'args': [{
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getCommonSysInfo',
        'authority': 'swanAPI',
        'path': '/getCommonSysInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.speak',
        'authority': 'tts',
        'path': '/speak',
        'args': [{
            'name': 'text',
            'value': 'string'
        }, {
            'name': 'auto',
            'value': 'boolean='
        }, {
            'name': 'speed',
            'value': 'string='
        }, {
            'name': 'pitch',
            'value': 'string='
        }, {
            'name': 'speaker',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.stop',
        'authority': 'tts',
        'path': '/stop',
        'args': [],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.resume',
        'authority': 'tts',
        'path': '/resume',
        'args': [],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.suspend',
        'authority': 'tts',
        'path': '/suspend',
        'args': [],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.register',
        'authority': 'swanAPI',
        'path': '/dataChannel/registerReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.pullMessage',
        'authority': 'swanAPI',
        'path': '/im/pullMsg',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.follow',
        'authority': 'follow',
        'path': '/action',
        'args': [{
            'name': 'actionType',
            'value': 'string'
        }, {
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getFollowStatus',
        'authority': 'follow',
        'path': '/getFollowStatus',
        'args': [{
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.sendBroadcast',
        'authority': 'swanAPI',
        'path': '/dataChannel/sendBroadcast',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.unRegister',
        'authority': 'swanAPI',
        'path': '/dataChannel/unregisterReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getBDUSS',
        'authority': 'swanAPI',
        'path': '/getBDUSS',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.openBdboxWebview',
        'authority': 'swanAPI',
        'path': '/pageTransition',
        'args': [{
            'name': 'module',
            'value': 'string='
        }, {
            'name': 'action',
            'value': 'string='
        }, {
            'name': 'scheme',
            'value': 'object='
        }, {
            'name': 'path',
            'value': 'string='
        }, {
            'name': 'authority',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getRealNameInfo',
        'authority': 'swanAPI',
        'path': '/getRealNameInfo',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getSeid',
        'authority': 'swanAPI',
        'path': '/quickPay/getSeid',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': 'Bdbox_android_jsbridge.dispatch'
    }];

    var androidv8List = [{
        'name': 'baidu.getPushSettingStateSync',
        'authority': 'swanAPI',
        'path': '/getPushSettingStateSync',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_aiapps_jsbridge.dispatch'
    }, {
        'name': 'baidu.getPrivateGetUserInfo',
        'authority': 'swanAPI',
        'path': '/privateGetUserInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.openWalkNavigation',
        'authority': 'swanAPI',
        'path': '/map/openWalkNavigation',
        'args': [{
            'name': 'latitude',
            'value': 'string'
        }, {
            'name': 'longitude',
            'value': 'string'
        }, {
            'name': 'guideKey',
            'value': 'string='
        }, {
            'name': 'guideIcon',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.requestWalletPolymerPayment',
        'authority': 'swanAPI',
        'path': '/requestWalletPolymerPayment',
        'args': [{
            'name': 'orderInfo',
            'value': 'object'
        }, {
            'name': 'reqData',
            'value': 'object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.thirdPartyLogin',
        'authority': 'swanAPI',
        'path': '/thirdPartyLogin',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }, {
            'name': 'timeout',
            'value': 'string='
        }, {
            'name': 'type',
            'value': {
                'oneOf': ['weibo', 'qq', 'weixin', 'sms']
            }
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getStoken',
        'authority': 'swanAPI',
        'path': '/getStoken',
        'args': [{
            'name': 'tpl',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.guidePushSetting',
        'authority': 'swanAPI',
        'path': '/guidePushSetting',
        'args': [{
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getCommonSysInfo',
        'authority': 'swanAPI',
        'path': '/getCommonSysInfo',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.speak',
        'authority': 'tts',
        'path': '/speak',
        'args': [{
            'name': 'text',
            'value': 'string'
        }, {
            'name': 'auto',
            'value': 'boolean='
        }, {
            'name': 'speed',
            'value': 'string='
        }, {
            'name': 'pitch',
            'value': 'string='
        }, {
            'name': 'speaker',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.stop',
        'authority': 'tts',
        'path': '/stop',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.resume',
        'authority': 'tts',
        'path': '/resume',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.tts.suspend',
        'authority': 'tts',
        'path': '/suspend',
        'args': [],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.register',
        'authority': 'swanAPI',
        'path': '/dataChannel/registerReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.pullMessage',
        'authority': 'swanAPI',
        'path': '/im/pullMsg',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.follow',
        'authority': 'follow',
        'path': '/action',
        'args': [{
            'name': 'actionType',
            'value': 'string'
        }, {
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getFollowStatus',
        'authority': 'follow',
        'path': '/getFollowStatus',
        'args': [{
            'name': 'type',
            'value': 'string'
        }, {
            'name': 'thirdID',
            'value': 'string'
        }, {
            'name': 'sfrom',
            'value': 'string='
        }, {
            'name': 'source',
            'value': 'string'
        }, {
            'name': 'store',
            'value': 'string='
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.sendBroadcast',
        'authority': 'swanAPI',
        'path': '/dataChannel/sendBroadcast',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.unRegister',
        'authority': 'swanAPI',
        'path': '/dataChannel/unregisterReceiver',
        'args': [{
            'name': 'action',
            'value': 'string'
        }, {
            'name': 'data',
            'value': 'object'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getBDUSS',
        'authority': 'swanAPI',
        'path': '/getBDUSS',
        'args': [{
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.openBdboxWebview',
        'authority': 'swanAPI',
        'path': '/pageTransition',
        'args': [{
            'name': 'module',
            'value': 'string='
        }, {
            'name': 'action',
            'value': 'string='
        }, {
            'name': 'scheme',
            'value': 'object='
        }, {
            'name': 'path',
            'value': 'string='
        }, {
            'name': 'authority',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getRealNameInfo',
        'authority': 'swanAPI',
        'path': '/getRealNameInfo',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getSeid',
        'authority': 'swanAPI',
        'path': '/quickPay/getSeid',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.launchCloudGame',
        'authority': 'swanAPI',
        'path': '/launchCloudGame',
        'args': [{
            'name': 'scheme',
            'value': 'string'
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getPayStatus',
        'authority': 'swanAPI',
        'path': '/quickPay/getPayStatus',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.addCard',
        'authority': 'swanAPI',
        'path': '/quickPay/addCard',
        'args': [{
            'name': 'cardType',
            'value': 'string='
        }, {
            'name': 'issuerId',
            'value': 'string='
        }, {
            'name': 'cardNum',
            'value': 'string'
        }, {
            'name': 'phoneNum',
            'value': 'string'
        }, {
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.getCardList',
        'authority': 'swanAPI',
        'path': '/quickPay/getCardList',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'ext',
            'value': 'Object='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }, {
        'name': 'baidu.launchPay',
        'authority': 'swanAPI',
        'path': '/quickPay/launchPay',
        'args': [{
            'name': 'reserve',
            'value': 'string='
        }, {
            'name': 'cb',
            'value': 'string'
        }],
        'invoke': 'swan.method.url',
        'method': '_naSwan.Bdbox_android_jsbridge.dispatch'
    }];

    var allDescription = [];

    var boxjsDescriptionList = ['baidu.getPrivateGetUserInfo'];

    if (!hasNoGlobal && $.isIOS) {
        allDescription = iosjscList;
    } else if (!hasNoGlobal && !$.isIOS) {
        allDescription = androidv8List;
    } else if ($.isIOS) {
        allDescription = ioswebviewList;
    } else {
        allDescription = androidwebviewList;
    }

    var INVOKE_LIST = {
        'swan.message.url': ['ArgCheck', 'ArgFuncArgDecode:JSON', 'ArgFuncEncode', 'ArgCombine:Object', 'SchemeCombine:URL', 'CallMessage'],

        'swan.prompt': ['ArgCheck', 'ArgFuncArgDecode:JSON', 'ArgFuncEncode', 'ArgCombine:Object', 'SchemeCombine:URLArrayString', 'CallPrompt'],

        'swan.method.urlArray': ['ArgCheck', 'ArgFuncArgDecode:JSON', 'ArgFuncEncode', 'ArgCombine:Object', 'SchemeCombine:URLArrayString', 'CallMethodAdpter'],

        'swan.method.url': ['ArgCheck', 'ArgFuncArgDecode:JSON', 'ArgFuncEncode', 'ArgCombine:Object', 'SchemeCombine:URLArray', 'CallMethodAdpter']
    };

    var DescCreator = function () {
        function DescCreator() {
            _classCallCheck(this, DescCreator);
        }

        _createClass(DescCreator, [{
            key: 'createDescList',
            value: function createDescList() {
                var classifiedDescriptions = allDescription.reduce(function (classifiedDescriptions, item) {
                    if (item.name.indexOf('Sync') === -1) {
                        item.args.push({ name: 'innerCallback', value: 'function' });
                    }

                    if (/\.insert|\.update|\.remove/.test(item.name) || ~boxjsDescriptionList.indexOf(item.name)) {
                        classifiedDescriptions.boxjsDescription.push(item);
                    } else {
                        classifiedDescriptions.swanDescription.push(item);
                    }

                    return classifiedDescriptions;
                }, {
                    swanDescription: [],
                    boxjsDescription: []
                });

                return classifiedDescriptions;
            }
        }]);

        return DescCreator;
    }();

    var callbackID = 0;
    var callbackManager = {
        callbackID: 0,

        getParamsCBName: function getParamsCBName() {
            return '_bdbox_extension_pjs_' + ++this.callbackID;
        },
        createLevel2Promise: function createLevel2Promise(params, parser) {
            params.cb = this.getParamsCBName();

            return new Promise(function (resolve, reject) {
                window[params.cb] = function (res) {
                    res = parser(res);

                    if (+res.status === 0) {
                        resolve(res.data);
                    } else {
                        reject({
                            errCode: res.status,
                            errMsg: res.message
                        });
                    }
                };
            });
        }
    };

    var createCallback = function createCallback(callback, parser) {
        var fnName = callbackManager.getParamsCBName();
        global[fnName] = function (res) {
            var data = parser(res);
            callback && callback(data.data);
        };
        return fnName;
    };

    function jsonParse(res) {
        var data = {};
        try {
            data = JSON.parse(res);
            data.status = +data.status;
        } catch (e) {
            data = res;
        }
        return data;
    }

    function resNeedDecode(res) {
        var result = jsonParse(res);
        var data = result.data || {};

        if (result.status === 0 && result.data && typeof result.data === 'string') {
            data = decodeURIComponent(result.data);
        }

        try {
            result.data = JSON.parse(data);
        } catch (e) {
            result.data = data;
        }

        return result;
    }

    function base64Decode(str) {
        try {
            str = decodeURIComponent(escape(globalNative.atob(str)));
        } catch (e) {
            console.warn('base64 decode fail', e);
        }
        return str;
    }

    function base64Parser(res) {
        res = jsonParse(res);

        res.data && (res.data = base64Decode(res.data));

        return resNeedDecode(res);
    }

    var executeByTryCatch = function executeByTryCatch(fn, errMsg, params) {
        try {
            fn && fn(params);
        } catch (error) {
            errMsg = error.message + ';' + errMsg;
            console.error('thirdScriptError\n' + errMsg + '\n' + error.stack);
        }
    };

    var executeCallback = function executeCallback(_ref2) {
        var promise = _ref2.promise,
            apiName = _ref2.apiName;
        var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};


        var ERROR_PREFIX = 'at api';
        var ERROR_SUFFIX = 'callback function';
        var ERROR_MSG = {
            success: ERROR_PREFIX + ' ' + apiName + ' success ' + ERROR_SUFFIX,
            fail: ERROR_PREFIX + ' ' + apiName + ' fail ' + ERROR_SUFFIX,
            complete: ERROR_PREFIX + ' ' + apiName + ' complete ' + ERROR_SUFFIX
        };

        if (promise instanceof Array) {
            Promise.all(promise).then(function (_ref3) {
                var _ref4 = _slicedToArray(_ref3, 2),
                    callbackRes = _ref4[0],
                    cbRes = _ref4[1];

                executeByTryCatch(params.success, ERROR_MSG.success, cbRes);
                executeByTryCatch(params.complete, ERROR_MSG.complete, cbRes);
            }).catch(function (err) {
                var result = err instanceof Error ? { errCode: 904, errMsg: err.message } : err;

                executeByTryCatch(params.fail, ERROR_MSG.fail, result);
                executeByTryCatch(params.complete, ERROR_MSG.complete, result);
            });
        } else {
            promise.then(function (res) {
                executeByTryCatch(params.success, ERROR_MSG.success, res);
                executeByTryCatch(params.complete, ERROR_MSG.complete, res);
            }).catch(function (err) {
                var result = err instanceof Error ? { errCode: 904, errMsg: err.message } : err;

                executeByTryCatch(params.fail, ERROR_MSG.fail, result);
                executeByTryCatch(params.complete, ERROR_MSG.complete, result);
            });
        }
    };

    var initGetTTSManager = function initGetTTSManager(boxjs) {
        var Event = function (_EventsEmitter) {
            _inherits(Event, _EventsEmitter);

            function Event() {
                _classCallCheck(this, Event);

                return _possibleConstructorReturn(this, (Event.__proto__ || Object.getPrototypeOf(Event)).apply(this, arguments));
            }

            _createClass(Event, [{
                key: 'once',
                value: function once(type, callback) {
                    this.onMessage(type, function (event) {
                        executeByTryCatch(callback, 'at callback', event.data);
                    }, {
                        once: true
                    });
                }
            }, {
                key: 'on',
                value: function on(type, callback) {
                    this.onMessage(type, function (event) {
                        executeByTryCatch(callback, 'at callback', event.data);
                    });
                }
            }, {
                key: 'emit',
                value: function emit(type, data) {
                    this.fireMessage({
                        type: type,
                        data: data
                    });
                }
            }]);

            return Event;
        }(EventsEmitter);

        var events = new Event();

        function dispatchEvent(res) {
            var eventType = void 0;
            switch (res.status) {
                case 0:
                    eventType = 'onSpeak';
                    break;
                case 1:
                case 4:
                    eventType = 'onError';
                    res.data = {
                        errCode: res.status,
                        errMsg: res.message
                    };
                    break;
                case 2:
                    eventType = 'onEnded';
                    break;
                case 3:
                    eventType = 'onStop';
                    break;
                case 5:
                    eventType = 'onPause';
                    break;
            }
            events.emit('ttsStateChange__' + eventType, res.data);
        }

        var ttsManager = {
            speak: function speak() {
                var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

                params.cb = callbackManager.getParamsCBName();
                global[params.cb] = function (res) {
                    var result = jsonParse(res);
                    dispatchEvent(result);
                };

                var promise = boxjs['baidu.tts.speak'](params);

                executeCallback({
                    promise: promise,
                    apiName: 'baidu.tts.speak'
                }, params);
            },
            pause: function pause() {
                this.__invokeMethod('suspend');
            },
            resume: function resume() {
                this.__invokeMethod('resume');
            },
            stop: function stop() {
                this.__invokeMethod('stop');
            },
            __invokeMethod: function __invokeMethod(operationType, data) {
                boxjs['baidu.tts.' + operationType](data);
            }
        };

        ['onSpeak', 'onStop', 'onPause', 'onEnded', 'onError'].forEach(function (listenerName) {
            ttsManager[listenerName] = function (callback) {
                var eventId = 'ttsStateChange__' + listenerName;

                events.handlerQueueSet.has(eventId) && events.delHandler(eventId);
                typeof callback === 'function' && events.on(eventId, callback);
            };
        });

        return function () {
            return ttsManager;
        };
    };

    var initRegister = function initRegister(boxjs) {
        return function () {
            var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            params.cb = createCallback(function (res) {
                executeByTryCatch(params.success, 'at api register success callback function', res);
            }, jsonParse);

            var apiName = 'baidu.register';
            var promise = boxjs[apiName](params);

            executeCallback({ promise: promise, apiName: apiName }, params);
        };
    };

    var initPullMessage = function initPullMessage(boxjs) {
        return function () {
            var params = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};

            params.cb = createCallback(function (res) {
                executeByTryCatch(params.success, 'at api pullMessage success callback function', res);
            }, jsonParse);

            var apiName = 'baidu.pullMessage';
            var promise = boxjs[apiName](params);

            executeCallback({ promise: promise, apiName: apiName }, params);
        };
    };

    var simpleApiList = ['getPushSettingStateSync', 'openTabopt', 'thirdPartyLogin', 'getStoken', 'getCommonSysInfo', 'follow', 'getFollowStatus', 'sendBroadcast', 'unRegister', 'getBDUSS', 'getRealNameInfo', 'guidePushSetting'];

    var androidApi = ['launchCloudGame', 'getPayStatus', 'addCard', 'getCardList', 'launchPay', 'getSeid'];

    if (!$.isIOS) {
        simpleApiList = simpleApiList.concat(androidApi);
    }

    var initComplexMap = {
        getTTSManager: initGetTTSManager,
        register: initRegister,
        pullMessage: initPullMessage
    };

    var simpleConfigMap = _extends({}, simpleApiList.reduce(function (accumulator, apiName) {
        accumulator[apiName] = {};
        return accumulator;
    }, {}), {
        guidePushSetting: {
            filter: function filter(params) {
                params.source = 'activity';
                return params;
            }
        },
        openWalkNavigation: {
            filter: function filter(params) {
                if (params.guideIcon) {
                    params.guideIcon = /^bdfile:\/\//.test(params.guideIcon) ? params.guideIcon : global.masterManager.getPathFromFront(params.guideIcon);
                }
                return params;
            }
        },
        requestWalletPolymerPayment: {
            parser: base64Parser
        },
        openBdboxWebview: {
            filter: function filter(params) {
                params.parameters = params.parameters ? params.parameters : {};
                params.scheme = params.parameters;
                delete params.parameters;
                params.scheme.upgrade = 0;
                if (params.module === 'wallet') {
                    params.scheme.url = 'https://www.baifubao.com/content/mywallet/h5/sdk_page/sdk_quan_manager.html';
                }
                return params;
            }
        }
    });

    var MethodCreator = function () {
        function MethodCreator(boxjs, desc) {
            _classCallCheck(this, MethodCreator);

            this.boxjs = boxjs;
            this.desc = desc.swanDescription;
        }

        _createClass(MethodCreator, [{
            key: 'createMethodMap',
            value: function createMethodMap() {
                var self = this;

                self.desc.forEach(function (item) {
                    var originName = item.name.replace(/^baidu\./, '');
                    if (simpleConfigMap[originName]) {
                        simpleConfigMap[originName].isCbRequired = item.args && item.args.some(function (arg) {
                            return arg.name === 'cb';
                        });
                    }
                });

                var simpleList = Object.keys(simpleConfigMap).reduce(function (accumulator, apiName) {
                    accumulator[apiName] = {
                        scope: 'root',
                        method: function method() {
                            var args = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
                            var _simpleConfigMap$apiN = simpleConfigMap[apiName],
                                filter = _simpleConfigMap$apiN.filter,
                                parser = _simpleConfigMap$apiN.parser,
                                isCbRequired = _simpleConfigMap$apiN.isCbRequired;


                            var params = _extends({}, args);

                            if (filter) {
                                params = filter(params);
                            }

                            if (apiName.match('Sync')) {
                                return self.boxjs['baidu.' + apiName](params);
                            }

                            var cbPromise = isCbRequired ? callbackManager.createLevel2Promise(params, parser || JSON.parse) : null;

                            var invokePromise = self.boxjs['baidu.' + apiName](params);

                            var promise = isCbRequired ? [invokePromise, cbPromise] : invokePromise;

                            executeCallback({
                                promise: promise,
                                apiName: apiName
                            }, params);
                        }
                    };
                    return accumulator;
                }, {});

                var complexList = Object.keys(initComplexMap).reduce(function (accumulator, apiName) {
                    var initMethod = initComplexMap[apiName];
                    accumulator[apiName] = {
                        scope: 'root',
                        method: initMethod(self.boxjs)
                    };
                    return accumulator;
                }, {});

                return _extends({}, simpleList, complexList);
            }
        }]);

        return MethodCreator;
    }();

    var getSdkVersion = function getSdkVersion() {
        var reg = /swan\/([\d+.]+)/;
        var version = '0';
        if (reg.exec(navigator.userAgent)) {
            version = reg.exec(navigator.userAgent)[1];
        }
        return version;
    };

    var versionCompare = function versionCompare(version1, version2) {
        version2 += '';
        version1 += '';

        var a = version1.split('.');
        var b = version2.split('.');
        var i = 0;
        var len = Math.max(a.length, b.length);

        for (; i < len; i++) {
            if (a[i] && !b[i] && parseInt(a[i]) > 0 || parseInt(a[i]) > parseInt(b[i])) {
                return 1;
            } else if (b[i] && !a[i] && parseInt(b[i]) > 0 || parseInt(a[i]) < parseInt(b[i])) {
                return -1;
            }
        }
        return 0;
    };

    define('swan-extension', ['swan', 'boxjs'], function (require, module, exports, define, swan, boxjs) {
        var descCreator = new DescCreator(boxjs);
        var desc = descCreator.createDescList();

        var methodsCreator = new MethodCreator(boxjs, desc);
        var methods = methodsCreator.createMethodMap();

        if (versionCompare(global.swanVersion, '3.50') >= 0) {
            module.exports = {
                name: 'baidu',
                hostMethodDescriptions: desc.swanDescription.concat(desc.boxjsDescription),
                methods: methods,
                components: {},
                customLog: function customLog(swanEventFlow) {}
            };
        } else {
            module.exports = {
                name: 'baidu',
                hostMethodDescriptions: [],
                methods: {},
                components: {},
                customLog: function customLog(swanEventFlow) {}
            };
        }
    });
})();
